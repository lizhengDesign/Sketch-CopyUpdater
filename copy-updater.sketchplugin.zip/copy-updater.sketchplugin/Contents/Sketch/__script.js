var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/script.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@skpm/dialog/lib/index.js":
/*!************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/index.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* let's try to match the API from Electron's Dialog
(https://github.com/electron/electron/blob/master/docs/api/dialog.md) */

module.exports = {
  showOpenDialog: __webpack_require__(/*! ./open-dialog */ "./node_modules/@skpm/dialog/lib/open-dialog.js").openDialog,
  showOpenDialogSync: __webpack_require__(/*! ./open-dialog */ "./node_modules/@skpm/dialog/lib/open-dialog.js").openDialogSync,
  showSaveDialog: __webpack_require__(/*! ./save-dialog */ "./node_modules/@skpm/dialog/lib/save-dialog.js").saveDialog,
  showSaveDialogSync: __webpack_require__(/*! ./save-dialog */ "./node_modules/@skpm/dialog/lib/save-dialog.js").saveDialogSync,
  showMessageBox: __webpack_require__(/*! ./message-box */ "./node_modules/@skpm/dialog/lib/message-box.js").messageBox,
  showMessageBoxSync: __webpack_require__(/*! ./message-box */ "./node_modules/@skpm/dialog/lib/message-box.js").messageBoxSync,
  // showErrorBox: require('./error-box'),
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/message-box.js":
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/message-box.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

var typeMap = {
  none: 0,
  info: 1,
  error: 2,
  question: 1,
  warning: 2,
}

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  } else if (document.sketchObject) {
    document = document.sketchObject
  }
  if (!options) {
    options = {}
  }

  var dialog = NSAlert.alloc().init()

  if (options.type) {
    dialog.alertStyle = typeMap[options.type] || 0
  }

  if (options.buttons && options.buttons.length) {
    options.buttons.forEach(function addButton(button) {
      dialog.addButtonWithTitle(
        options.normalizeAccessKeys ? button.replace(/&/g, '') : button
      )
      // TODO: add keyboard shortcut if options.normalizeAccessKeys
    })
  }

  if (typeof options.defaultId !== 'undefined') {
    var buttons = dialog.buttons()
    if (options.defaultId < buttons.length) {
      // Focus the button at defaultId if the user opted to do so.
      // The first button added gets set as the default selected.
      // So remove that default, and make the requested button the default.
      buttons[0].setKeyEquivalent('')
      buttons[options.defaultId].setKeyEquivalent('\r')
    }
  }

  if (options.title) {
    // not shown on macOS
  }

  if (options.message) {
    dialog.messageText = options.message
  }

  if (options.detail) {
    dialog.informativeText = options.detail
  }

  if (options.checkboxLabel) {
    dialog.showsSuppressionButton = true
    dialog.suppressionButton().title = options.checkboxLabel

    if (typeof options.checkboxChecked !== 'undefined') {
      dialog.suppressionButton().state = options.checkboxChecked
        ? NSOnState
        : NSOffState
    }
  }

  if (options.icon) {
    if (typeof options.icon === 'string') {
      options.icon = NSImage.alloc().initWithContentsOfFile(options.icon)
    }
    dialog.icon = options.icon
  } else if (
    typeof __command !== 'undefined' &&
    __command.pluginBundle() &&
    __command.pluginBundle().icon()
  ) {
    dialog.icon = __command.pluginBundle().icon()
  } else {
    var icon = NSImage.imageNamed('plugins')
    if (icon) {
      dialog.icon = icon
    }
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowmessageboxbrowserwindow-options
module.exports.messageBox = function messageBox(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return {
        response:
          setup.options.buttons && setup.options.buttons.length
            ? Number(returnCode) - 1000
            : Number(returnCode),
        checkboxChecked: _dialog.suppressionButton().state() == NSOnState,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowmessageboxsyncbrowserwindow-options
module.exports.messageBoxSync = function messageBoxSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return setup.options.buttons && setup.options.buttons.length
        ? Number(returnCode) - 1000
        : Number(returnCode)
    },
    setup.document
  )
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/open-dialog.js":
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/open-dialog.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  }
  if (!options) {
    options = {}
  }

  var dialog = NSOpenPanel.openPanel()

  if (options.title) {
    dialog.title = options.title
  }

  if (options.defaultPath) {
    dialog.setDirectoryURL(utils.getURL(options.defaultPath))
  }

  if (options.buttonLabel) {
    dialog.prompt = options.buttonLabel
  }

  if (options.filters && options.filters.length) {
    var exts = []
    options.filters.forEach(function setFilter(filter) {
      filter.extensions.forEach(function setExtension(ext) {
        exts.push(ext)
      })
    })

    dialog.allowedFileTypes = exts
  }

  var hasProperty =
    Array.isArray(options.properties) && options.properties.length > 0
  dialog.canChooseFiles =
    hasProperty && options.properties.indexOf('openFile') !== -1
  dialog.canChooseDirectories =
    hasProperty && options.properties.indexOf('openDirectory') !== -1
  dialog.allowsMultipleSelection =
    hasProperty && options.properties.indexOf('multiSelections') !== -1
  dialog.showsHiddenFiles =
    hasProperty && options.properties.indexOf('showHiddenFiles') !== -1
  dialog.canCreateDirectories =
    hasProperty && options.properties.indexOf('createDirectory') !== -1
  dialog.resolvesAliases =
    !hasProperty || options.properties.indexOf('noResolveAliases') === -1
  dialog.treatsFilePackagesAsDirectories =
    hasProperty && options.properties.indexOf('treatPackageAsDirectory') !== -1

  if (options.message) {
    dialog.message = options.message
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowopendialogbrowserwindow-options
module.exports.openDialog = function openDialog(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      if (returnCode != NSOKButton) {
        return {
          canceled: true,
          filePaths: [],
        }
      }
      var result = []
      var urls = _dialog.URLs()
      for (var k = 0; k < urls.length; k += 1) {
        result.push(String(urls[k].path()))
      }
      return {
        canceled: false,
        filePaths: result,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowopendialogsyncbrowserwindow-options
module.exports.openDialogSync = function openDialogSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      if (returnCode != NSOKButton) {
        return []
      }
      var result = []
      var urls = _dialog.URLs()
      for (var k = 0; k < urls.length; k += 1) {
        result.push(String(urls[k].path()))
      }
      return result
    },
    setup.document
  )
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/save-dialog.js":
/*!******************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/save-dialog.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/dialog/lib/utils.js")

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  }
  if (!options) {
    options = {}
  }

  var dialog = NSSavePanel.savePanel()

  if (options.title) {
    dialog.title = options.title
  }

  if (options.defaultPath) {
    // that's a path
    dialog.setDirectoryURL(utils.getURL(options.defaultPath))

    if (
      options.defaultPath[0] === '.' ||
      options.defaultPath[0] === '~' ||
      options.defaultPath[0] === '/'
    ) {
      var parts = options.defaultPath.split('/')
      if (parts.length > 1 && parts[parts.length - 1]) {
        dialog.setNameFieldStringValue(parts[parts.length - 1])
      }
    } else {
      dialog.setNameFieldStringValue(options.defaultPath)
    }
  }

  if (options.buttonLabel) {
    dialog.prompt = options.buttonLabel
  }

  if (options.filters && options.filters.length) {
    var exts = []
    options.filters.forEach(function setFilter(filter) {
      filter.extensions.forEach(function setExtension(ext) {
        exts.push(ext)
      })
    })

    if (dialog.allowedContentTypes) {
      // Big Sur and newer.
      dialog.allowedContentTypes = exts.map((ext) => UTType.typeWithFilenameExtension(ext))
    } else {
      // Catalina and older.
      dialog.allowedFileTypes = exts
    }
  }

  if (options.message) {
    dialog.message = options.message
  }

  if (options.nameFieldLabel) {
    dialog.nameFieldLabel = options.nameFieldLabel
  }

  if (options.showsTagField) {
    dialog.showsTagField = options.showsTagField
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowsavedialogbrowserwindow-options
module.exports.saveDialog = function saveDialog(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return {
        canceled: returnCode != NSOKButton,
        filePath:
          returnCode == NSOKButton ? String(_dialog.URL().path()) : undefined,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowsavedialogsyncbrowserwindow-options
module.exports.saveDialogSync = function saveDialogSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return returnCode == NSOKButton ? String(_dialog.URL().path()) : undefined
    },
    setup.document
  )
}


/***/ }),

/***/ "./node_modules/@skpm/dialog/lib/utils.js":
/*!************************************************!*\
  !*** ./node_modules/@skpm/dialog/lib/utils.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {module.exports.getURL = function getURL(path) {
  return NSURL.URLWithString(
    String(
      NSString.stringWithString(path).stringByExpandingTildeInPath()
    ).replace(/ /g, '%20')
  )
}

module.exports.runDialog = function runDialog(dialog, getResult, document) {
  if (!document) {
    var returnCode = dialog.runModal()
    return Promise.resolve(getResult(dialog, returnCode))
  }

  var fiber = coscript.createFiber()

  var window = (document.sketchObject || document).documentWindow()

  return new Promise(function p(resolve, reject) {
    dialog.beginSheetModalForWindow_completionHandler(
      window,
      __mocha__.createBlock_function('v16@?0q8', function onCompletion(
        _returnCode
      ) {
        try {
          resolve(getResult(dialog, _returnCode))
        } catch (err) {
          reject(err)
        }
        NSApp.endSheet(dialog)
        if (fiber) {
          fiber.cleanup()
        } else {
          coscript.shouldKeepAround = false
        }
      })
    )
  })
}

module.exports.runDialogSync = function runDialog(dialog, getResult, document) {
  var returnCode

  if (!document) {
    returnCode = dialog.runModal()
    return getResult(dialog, returnCode)
  }

  var window = (document.sketchObject || document).documentWindow()

  dialog.beginSheetModalForWindow_completionHandler(
    window,
    __mocha__.createBlock_function('v16@?0q8', function onCompletion(
      _returnCode
    ) {
      NSApp.stopModalWithCode(_returnCode)
    })
  )

  returnCode = NSApp.runModalForWindow(window)
  NSApp.endSheet(dialog)
  return getResult(dialog, returnCode)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/@skpm/fs/index.js":
/*!****************************************!*\
  !*** ./node_modules/@skpm/fs/index.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// TODO: async. Should probably be done with NSFileHandle and some notifications
// TODO: file descriptor. Needs to be done with NSFileHandle
var Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/fs/utils.js");
var parseStat = utils.parseStat;
var fsError = utils.fsError;
var fsErrorForPath = utils.fsErrorForPath;
var encodingFromOptions = utils.encodingFromOptions;
var NOT_IMPLEMENTED = utils.NOT_IMPLEMENTED;

module.exports.constants = {
  F_OK: 0,
  R_OK: 4,
  W_OK: 2,
  X_OK: 1,
};

module.exports.access = NOT_IMPLEMENTED("access");

module.exports.accessSync = function (path, mode) {
  mode = mode | 0;
  var fileManager = NSFileManager.defaultManager();

  switch (mode) {
    case 0:
      canAccess = module.exports.existsSync(path);
      break;
    case 1:
      canAccess = Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
    case 2:
      canAccess = Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 3:
      canAccess =
        Boolean(Number(fileManager.isExecutableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 4:
      canAccess = Boolean(Number(fileManager.isReadableFileAtPath(path)));
      break;
    case 5:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
    case 6:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 7:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path))) &&
        Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
  }

  if (!canAccess) {
    throw new Error("Can't access " + String(path));
  }
};

module.exports.appendFile = NOT_IMPLEMENTED("appendFile");

module.exports.appendFileSync = function (file, data, options) {
  if (!module.exports.existsSync(file)) {
    return module.exports.writeFileSync(file, data, options);
  }

  var handle = NSFileHandle.fileHandleForWritingAtPath(file);
  handle.seekToEndOfFile();

  var encoding = encodingFromOptions(options, "utf8");

  var nsdata = Buffer.from(
    data,
    encoding === "NSData" || encoding === "buffer" ? undefined : encoding
  ).toNSData();

  handle.writeData(nsdata);
};

module.exports.chmod = NOT_IMPLEMENTED("chmod");

module.exports.chmodSync = function (path, mode) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.setAttributes_ofItemAtPath_error(
    {
      NSFilePosixPermissions: mode,
    },
    path,
    err
  );

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }
};

module.exports.chown = NOT_IMPLEMENTED("chown");
module.exports.chownSync = NOT_IMPLEMENTED("chownSync");

module.exports.close = NOT_IMPLEMENTED("close");
module.exports.closeSync = NOT_IMPLEMENTED("closeSync");

module.exports.copyFile = NOT_IMPLEMENTED("copyFile");

module.exports.copyFileSync = function (path, dest, flags) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.copyItemAtPath_toPath_error(path, dest, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value());
  }
};

module.exports.createReadStream = NOT_IMPLEMENTED("createReadStream");
module.exports.createWriteStream = NOT_IMPLEMENTED("createWriteStream");

module.exports.exists = NOT_IMPLEMENTED("exists");

module.exports.existsSync = function (path) {
  var fileManager = NSFileManager.defaultManager();
  return Boolean(Number(fileManager.fileExistsAtPath(path)));
};

module.exports.fchmod = NOT_IMPLEMENTED("fchmod");
module.exports.fchmodSync = NOT_IMPLEMENTED("fchmodSync");
module.exports.fchown = NOT_IMPLEMENTED("fchown");
module.exports.fchownSync = NOT_IMPLEMENTED("fchownSync");
module.exports.fdatasync = NOT_IMPLEMENTED("fdatasync");
module.exports.fdatasyncSync = NOT_IMPLEMENTED("fdatasyncSync");
module.exports.fstat = NOT_IMPLEMENTED("fstat");
module.exports.fstatSync = NOT_IMPLEMENTED("fstatSync");
module.exports.fsync = NOT_IMPLEMENTED("fsync");
module.exports.fsyncSync = NOT_IMPLEMENTED("fsyncSync");
module.exports.ftruncate = NOT_IMPLEMENTED("ftruncate");
module.exports.ftruncateSync = NOT_IMPLEMENTED("ftruncateSync");
module.exports.futimes = NOT_IMPLEMENTED("futimes");
module.exports.futimesSync = NOT_IMPLEMENTED("futimesSync");

module.exports.lchmod = NOT_IMPLEMENTED("lchmod");
module.exports.lchmodSync = NOT_IMPLEMENTED("lchmodSync");
module.exports.lchown = NOT_IMPLEMENTED("lchown");
module.exports.lchownSync = NOT_IMPLEMENTED("lchownSync");

module.exports.link = NOT_IMPLEMENTED("link");

module.exports.linkSync = function (existingPath, newPath) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.linkItemAtPath_toPath_error(existingPath, newPath, err);

  if (err.value() !== null) {
    throw fsErrorForPath(existingPath, undefined, err.value());
  }
};

module.exports.lstat = NOT_IMPLEMENTED("lstat");

module.exports.lstatSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.attributesOfItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }

  return parseStat(result);
};

module.exports.mkdir = NOT_IMPLEMENTED("mkdir");

module.exports.mkdirSync = function (path, options) {
  var mode = 0o777;
  var recursive = false;
  if (options && options.mode) {
    mode = options.mode;
  }
  if (options && options.recursive) {
    recursive = options.recursive;
  }
  if (typeof options === "number") {
    mode = options;
  }
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error(
    path,
    recursive,
    {
      NSFilePosixPermissions: mode,
    },
    err
  );

  if (err.value() !== null) {
    throw new Error(err.value());
  }
};

module.exports.mkdtemp = NOT_IMPLEMENTED("mkdtemp");

module.exports.mkdtempSync = function (path) {
  function makeid() {
    var text = "";
    var possible =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 6; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }
  var tempPath = path + makeid();
  module.exports.mkdirSync(tempPath);
  return tempPath;
};

module.exports.open = NOT_IMPLEMENTED("open");
module.exports.openSync = NOT_IMPLEMENTED("openSync");

module.exports.read = NOT_IMPLEMENTED("read");

module.exports.readdir = NOT_IMPLEMENTED("readdir");

module.exports.readdirSync = function (path, options) {
  var encoding = encodingFromOptions(options, "utf8");
  var fileManager = NSFileManager.defaultManager();
  var paths = fileManager.subpathsAtPath(path);
  var arr = [];
  for (var i = 0; i < paths.length; i++) {
    var pathName = paths[i];
    arr.push(encoding === "buffer" ? Buffer.from(pathName) : String(pathName));
  }
  return arr;
};

module.exports.readFile = NOT_IMPLEMENTED("readFile");

module.exports.readFileSync = function (path, options) {
  var encoding = encodingFromOptions(options, "buffer");
  var fileManager = NSFileManager.defaultManager();
  var data = fileManager.contentsAtPath(path);
  if (!data) {
    throw fsErrorForPath(path, false);
  }

  var buffer = Buffer.from(data);

  if (encoding === "buffer") {
    return buffer;
  } else if (encoding === "NSData") {
    return buffer.toNSData();
  } else {
    return buffer.toString(encoding);
  }
};

module.exports.readlink = NOT_IMPLEMENTED("readlink");

module.exports.readlinkSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.destinationOfSymbolicLinkAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }

  return String(result);
};

module.exports.readSync = NOT_IMPLEMENTED("readSync");

module.exports.realpath = NOT_IMPLEMENTED("realpath");
module.exports.realpath.native = NOT_IMPLEMENTED("realpath.native");

module.exports.realpathSync = function (path) {
  return String(
    NSString.stringWithString(path).stringByResolvingSymlinksInPath()
  );
};

module.exports.realpathSync.native = NOT_IMPLEMENTED("realpathSync.native");

module.exports.rename = NOT_IMPLEMENTED("rename");

module.exports.renameSync = function (oldPath, newPath) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.moveItemAtPath_toPath_error(oldPath, newPath, err);

  var error = err.value();

  if (error !== null) {
    // if there is already a file, we need to overwrite it
    if (
      String(error.domain()) === "NSCocoaErrorDomain" &&
      Number(error.code()) === 516
    ) {
      var err2 = MOPointer.alloc().init();
      fileManager.replaceItemAtURL_withItemAtURL_backupItemName_options_resultingItemURL_error(
        NSURL.fileURLWithPath(newPath),
        NSURL.fileURLWithPath(oldPath),
        null,
        NSFileManagerItemReplacementUsingNewMetadataOnly,
        null,
        err2
      );
      if (err2.value() !== null) {
        throw fsErrorForPath(oldPath, undefined, err2.value());
      }
    } else {
      throw fsErrorForPath(oldPath, undefined, error);
    }
  }
};

module.exports.rmdir = NOT_IMPLEMENTED("rmdir");

module.exports.rmdirSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var isDirectory = module.exports.lstatSync(path).isDirectory();
  if (!isDirectory) {
    throw fsError("ENOTDIR", {
      path: path,
      syscall: "rmdir",
    });
  }
  fileManager.removeItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, true, err.value(), "rmdir");
  }
};

module.exports.stat = NOT_IMPLEMENTED("stat");

// the only difference with lstat is that we resolve symlinks
//
// > lstat() is identical to stat(), except that if pathname is a symbolic
// > link, then it returns information about the link itself, not the file
// > that it refers to.
// http://man7.org/linux/man-pages/man2/lstat.2.html
module.exports.statSync = function (path) {
  return module.exports.lstatSync(module.exports.realpathSync(path));
};

module.exports.symlink = NOT_IMPLEMENTED("symlink");

module.exports.symlinkSync = function (target, path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.createSymbolicLinkAtPath_withDestinationPath_error(
    path,
    target,
    err
  );

  if (err.value() !== null) {
    throw new Error(err.value());
  }
};

module.exports.truncate = NOT_IMPLEMENTED("truncate");

module.exports.truncateSync = function (path, len) {
  var hFile = NSFileHandle.fileHandleForUpdatingAtPath(sFilePath);
  hFile.truncateFileAtOffset(len || 0);
  hFile.closeFile();
};

module.exports.unlink = NOT_IMPLEMENTED("unlink");

module.exports.unlinkSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var isDirectory = module.exports.lstatSync(path).isDirectory();
  if (isDirectory) {
    throw fsError("EPERM", {
      path: path,
      syscall: "unlink",
    });
  }
  var result = fileManager.removeItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value());
  }
};

module.exports.unwatchFile = NOT_IMPLEMENTED("unwatchFile");

module.exports.utimes = NOT_IMPLEMENTED("utimes");

module.exports.utimesSync = function (path, aTime, mTime) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.setAttributes_ofItemAtPath_error(
    {
      NSFileModificationDate: aTime,
    },
    path,
    err
  );

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }
};

module.exports.watch = NOT_IMPLEMENTED("watch");
module.exports.watchFile = NOT_IMPLEMENTED("watchFile");

module.exports.write = NOT_IMPLEMENTED("write");

module.exports.writeFile = NOT_IMPLEMENTED("writeFile");

module.exports.writeFileSync = function (path, data, options) {
  var encoding = encodingFromOptions(options, "utf8");

  var nsdata = Buffer.from(
    data,
    encoding === "NSData" || encoding === "buffer" ? undefined : encoding
  ).toNSData();

  nsdata.writeToFile_atomically(path, true);
};

module.exports.writeSync = NOT_IMPLEMENTED("writeSync");


/***/ }),

/***/ "./node_modules/@skpm/fs/utils.js":
/*!****************************************!*\
  !*** ./node_modules/@skpm/fs/utils.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports.parseStat = function parseStat(result) {
  return {
    dev: String(result.NSFileDeviceIdentifier),
    // ino: 48064969, The file system specific "Inode" number for the file.
    mode: result.NSFileType | result.NSFilePosixPermissions,
    nlink: Number(result.NSFileReferenceCount),
    uid: String(result.NSFileOwnerAccountID),
    gid: String(result.NSFileGroupOwnerAccountID),
    // rdev: 0, A numeric device identifier if the file is considered "special".
    size: Number(result.NSFileSize),
    // blksize: 4096, The file system block size for i/o operations.
    // blocks: 8, The number of blocks allocated for this file.
    atimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    mtimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    ctimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    birthtimeMs:
      Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000,
    atime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ), // the 0.5 comes from the node source. Not sure why it's added but in doubt...
    mtime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    ctime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    birthtime: new Date(
      Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    isBlockDevice: function () {
      return result.NSFileType === NSFileTypeBlockSpecial;
    },
    isCharacterDevice: function () {
      return result.NSFileType === NSFileTypeCharacterSpecial;
    },
    isDirectory: function () {
      return result.NSFileType === NSFileTypeDirectory;
    },
    isFIFO: function () {
      return false;
    },
    isFile: function () {
      return result.NSFileType === NSFileTypeRegular;
    },
    isSocket: function () {
      return result.NSFileType === NSFileTypeSocket;
    },
    isSymbolicLink: function () {
      return result.NSFileType === NSFileTypeSymbolicLink;
    },
  };
};

var ERRORS = {
  EPERM: {
    message: "operation not permitted",
    errno: -1,
  },
  ENOENT: {
    message: "no such file or directory",
    errno: -2,
  },
  EACCES: {
    message: "permission denied",
    errno: -13,
  },
  ENOTDIR: {
    message: "not a directory",
    errno: -20,
  },
  EISDIR: {
    message: "illegal operation on a directory",
    errno: -21,
  },
};

function fsError(code, options) {
  var error = new Error(
    code +
      ": " +
      ERRORS[code].message +
      ", " +
      (options.syscall || "") +
      (options.path ? " '" + options.path + "'" : "")
  );

  Object.keys(options).forEach(function (k) {
    error[k] = options[k];
  });

  error.code = code;
  error.errno = ERRORS[code].errno;

  return error;
}

module.exports.fsError = fsError;

module.exports.fsErrorForPath = function fsErrorForPath(
  path,
  shouldBeDir,
  err,
  syscall
) {
  var fileManager = NSFileManager.defaultManager();
  var doesExist = fileManager.fileExistsAtPath(path);
  if (!doesExist) {
    return fsError("ENOENT", {
      path: path,
      syscall: syscall || "open",
    });
  }
  var isReadable = fileManager.isReadableFileAtPath(path);
  if (!isReadable) {
    return fsError("EACCES", {
      path: path,
      syscall: syscall || "open",
    });
  }
  if (typeof shouldBeDir !== "undefined") {
    var isDirectory = __webpack_require__(/*! ./index */ "./node_modules/@skpm/fs/index.js").lstatSync(path).isDirectory();
    if (isDirectory && !shouldBeDir) {
      return fsError("EISDIR", {
        path: path,
        syscall: syscall || "read",
      });
    } else if (!isDirectory && shouldBeDir) {
      return fsError("ENOTDIR", {
        path: path,
        syscall: syscall || "read",
      });
    }
  }
  return new Error(err || "Unknown error while manipulating " + path);
};

module.exports.encodingFromOptions = function encodingFromOptions(
  options,
  defaultValue
) {
  return options && options.encoding
    ? String(options.encoding)
    : options
    ? String(options)
    : defaultValue;
};

module.exports.NOT_IMPLEMENTED = function NOT_IMPLEMENTED(name) {
  return function () {
    throw new Error(
      "fs." +
        name +
        " is not implemented yet. If you feel like implementing it, any contribution will be gladly accepted on https://github.com/skpm/fs"
    );
  };
};


/***/ }),

/***/ "./node_modules/@skpm/promise/index.js":
/*!*********************************************!*\
  !*** ./node_modules/@skpm/promise/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ }),

/***/ "./src/script.js":
/*!***********************!*\
  !*** ./src/script.js ***!
  \***********************/
/*! exports provided: checkUpdateOnOpenDocument, checkUpdate, resetCopy, pullCopy, pushCopy, generateJSON, setupJSON */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkUpdateOnOpenDocument", function() { return checkUpdateOnOpenDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkUpdate", function() { return checkUpdate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetCopy", function() { return resetCopy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pullCopy", function() { return pullCopy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pushCopy", function() { return pushCopy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateJSON", function() { return generateJSON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setupJSON", function() { return setupJSON; });
/* harmony import */ var _skpm_dialog__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @skpm/dialog */ "./node_modules/@skpm/dialog/lib/index.js");
/* harmony import */ var _skpm_dialog__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_skpm_dialog__WEBPACK_IMPORTED_MODULE_0__);


var fs = __webpack_require__(/*! @skpm/fs */ "./node_modules/@skpm/fs/index.js");

var sketch = __webpack_require__(/*! sketch */ "sketch");

var Settings = sketch.Settings;
var doc = sketch.getSelectedDocument();
var selectedLayers = doc.selectedLayers;
var JSONPath = "";
var isJSONPathUpdated = false;
var maxPanelHeight = 480;
var panelMargin = 20;
var itemWidth = 200;
var panelWidth = itemWidth * 3 + panelMargin * 6;
var itemHeight = 60;
var scrollBarWidth = 16;
var layerType = {
  PAGE: "Page",
  ARTBOARD: "Artboard",
  SHAPEPATH: "ShapePath",
  TEXT: "Text",
  SYMBOLINSTANCE: "SymbolInstance",
  SYMBOLMASTER: "SymbolMaster"
};
var updateType = {
  KEY: 0,
  FROM_JSON: 1,
  TO_JSON: 2,
  MIXED: 3
};
var updateDirection = {
  TO_JSON: true,
  FROM_JSON: false
};
var prefernceKey = {
  IS_CHECK: "isCheckOnOpenDocument",
  HAS_DOCUMENTATION: "hasCopyDocumentation",
  HAS_EDITABLE_ONLY_SELECTED: "hasExportEditableOnlySelected",
  CHECK_SCOPE: "copyCheckScope",
  KEY: "lzhengCopyUpdaterKey",
  JSON_PATH: "lzhengCopyUPdaterJSONPath",
  UPDATE_DIRECTION: "lzhengCopyUpdaterDirection",
  COPY_GROUP_CONFIG: "lzhengCopyUpdaterCopyConfig",
  COPY_PAGE_ID: "lzhengCopyUpdaterIndexPageId"
};
var copyBlockSpec = {
  secondaryMargin: 4,
  primaryMargin: 16,
  sectionMargin: 64,
  keyStyle: {
    textColor: "#00000099",
    fontSize: 14,
    lineHeight: 16,
    fontWeight: 4,
    alignment: sketch.Text.Alignment.left
  },
  valueStyle: {
    textColor: "#000000EE",
    fontSize: 16,
    lineHeight: 20,
    fontWeight: 8,
    alignment: sketch.Text.Alignment.left
  },
  copyPageName: "[Copy Index]",
  copyPrefix: "[Copy]: ",
  copyBlockWidth: 500,
  copyTitleHeight: 60
};

var readJSONAsObject = function readJSONAsObject(path) {
  try {
    var data = JSON.parse(fs.readFileSync(path));
    return data;
  } catch (error) {
    return {};
  }
};

var readDatafromConfig = function readDatafromConfig(path) {
  JSONPath = path ? path : Settings.documentSettingForKey(doc, prefernceKey.KEY);

  if (!JSONPath) {
    sketch.UI.message("No copy JSON file found");
    return undefined;
  } else {
    var copyData = readJSONAsObject(JSONPath);

    if (Object.keys(copyData).length === 0) {
      sketch.UI.message("❌ The JSON file was removed, empty, or contains error. Please select another one or fix it.");
    } else return copyData;
  }

  return undefined;
};

var resolveValue = function resolveValue(path, data) {
  if (!path) return undefined;
  var copyValue = path.split(/\.|\]\.|\[|\]\[|\]/).reduce(function (prev, curr) {
    if (curr === "") return prev;
    return prev ? prev[curr] : null;
  }, data || self);

  if (typeof copyValue != "string") {
    return undefined;
  } else return copyValue;
};

var setValue = function setValue(path, data, value) {
  var pathList = path.split(".");
  pathList.reduce(function (prev, curr, index) {
    if (index == pathList.length - 1) {
      prev[curr] = value;
    }

    if (!prev[curr]) prev[curr] = {};
    return prev ? prev[curr] : null;
  }, data || self);
};

var createCopyKeyValueGroup = function createCopyKeyValueGroup(copyKey, JSONValue, parentGroup, index) {
  var key = new sketch.Text({
    text: copyKey,
    parent: parentGroup,
    fixedWidth: true,
    style: copyBlockSpec.keyStyle,
    frame: {
      x: 0,
      y: index == 0 ? parentGroup.frame.height + copyBlockSpec.sectionMargin : parentGroup.frame.height + copyBlockSpec.primaryMargin,
      width: copyBlockSpec.copyBlockWidth,
      height: 0
    }
  }).adjustToFit();
  var value = new sketch.Text({
    text: JSONValue,
    parent: parentGroup,
    fixedWidth: true,
    style: copyBlockSpec.valueStyle,
    frame: {
      x: 0,
      y: key.frame.y + key.frame.height + copyBlockSpec.secondaryMargin,
      width: copyBlockSpec.copyBlockWidth,
      height: 0
    }
  }).adjustToFit();
  new sketch.Group({
    name: copyKey,
    parent: parentGroup,
    layers: [value, key]
  }).adjustToFit().moveToBack();
  parentGroup.adjustToFit();
};

var updateText = function updateText(layer, value) {
  if (layer.type == layerType.TEXT) {
    layer.text = value;
  } else layer.value = value;
};

var getFileName = function getFileName(path) {
  if (!path) return undefined;
  var name = path.substr(path.lastIndexOf("/") + 1);
  name = name.lastIndexOf(".") != -1 ? name.substr(0, name.lastIndexOf(".")) : name;
  return name;
};

var syncCopyDoc = function syncCopyDoc(copyData) {
  var JSONPath = Settings.documentSettingForKey(doc, prefernceKey.KEY);
  var JSONName = getFileName(JSONPath);
  var copyPageId = Settings.documentSettingForKey(doc, prefernceKey.COPY_PAGE_ID);
  var copyPage = doc.getLayerWithID(copyPageId) ? doc.getLayerWithID(copyPageId) : new sketch.Page({
    name: copyBlockSpec.copyPageName + " (Reference Only)",
    parent: doc
  });
  Settings.setDocumentSettingForKey(doc, prefernceKey.COPY_PAGE_ID, copyPage.id);
  var copyGroupConfig = Settings.layerSettingForKey(copyPage, prefernceKey.COPY_GROUP_CONFIG) ? Settings.layerSettingForKey(copyPage, prefernceKey.COPY_GROUP_CONFIG) : {};
  var copyGroup = doc.getLayerWithID(copyGroupConfig[JSONPath]) ? doc.getLayerWithID(copyGroupConfig[JSONPath]) : new sketch.Group({
    name: copyBlockSpec.copyPageName + ": " + JSONName,
    parent: copyPage
  });
  copyGroupConfig[JSONPath] = copyGroup.id;
  copyGroup.layers.forEach(function (layer) {
    return layer.remove();
  });
  copyGroup.frame.y -= copyBlockSpec.sectionMargin;
  copyGroup.frame.height = 0;
  Settings.setLayerSettingForKey(copyPage, prefernceKey.COPY_GROUP_CONFIG, copyGroupConfig);

  var traverseData = function traverseData(key, data, index) {
    if (typeof data == "string") {
      createCopyKeyValueGroup(key, data, copyGroup, index ? index : 0);
    } else {
      Object.keys(data).forEach(function (nextKey, index) {
        return traverseData(key + "." + nextKey, data[nextKey], index);
      });
    }
  };

  Object.keys(copyData).forEach(function (key) {
    return traverseData("@" + key, copyData[key]);
  });
};

var camelize = function camelize(string) {
  return string.replace(/(?:^\w|[A-Z]|\b\w)/g, function (word, index) {
    return index === 0 ? word.toLowerCase() : word.toUpperCase();
  }).replace(/\s+/g, "");
};

var getFullName = function getFullName(instance, copyItem) {
  var symbolDoc = instance.master.getLibrary() == null ? doc : instance.master.getLibrary().getDocument();
  var pathList = copyItem.path.split("/");
  var name = "";
  pathList.forEach(function (id) {
    var element = symbolDoc.getLayerWithID(id);

    if (element != undefined) {
      name += camelize(element.name) + ".";

      if (element.type != layerType.TEXT) {
        symbolDoc = element.master.getLibrary() == null ? symbolDoc : element.master.getLibrary().getDocument();
      }
    }
  });
  name = name.substr(0, name.length - 1);
  return name;
};

var updateTextByType = function updateTextByType(type) {
  if (selectedLayers.isEmpty) {
    sketch.UI.message("❌ Please select at least 1 layer or artboard.");
    return;
  }

  var copyData = readDatafromConfig();
  if (!copyData) return;
  var updateCounter = 0;

  var updateCopyBasedOnDirection = function updateCopyBasedOnDirection(item, index, direction, itemType) {
    copyData = isJSONPathUpdated ? copyData : readDatafromConfig(Settings.layerSettingForKey(item, prefernceKey.JSON_PATH));
    if (!copyData) return;
    var copyKey;
    var JSONValue = undefined;
    var storedKey = Settings.layerSettingForKey(item, prefernceKey.KEY);
    var copyItem = itemType == layerType.TEXT ? item : item.overrides[index];
    var lineHeight = itemType == layerType.TEXT ? item.style.lineHeight == null ? item.style.getDefaultLineHeight() : item.style.lineHeight : copyItem.affectedLayer.style.lineHeight;
    var onDisplayValue = itemType == layerType.TEXT ? item.text : copyItem.value;
    if (!storedKey) storedKey = {};

    switch (onDisplayValue[0]) {
      case "@":
        copyKey = onDisplayValue.slice(1);
        storedKey[index] = copyKey;
        Settings.setLayerSettingForKey(item, prefernceKey.KEY, storedKey);
        if (isJSONPathUpdated || !Settings.layerSettingForKey(item, prefernceKey.JSON_PATH)) Settings.setLayerSettingForKey(item, prefernceKey.JSON_PATH, JSONPath);
        break;

      case "-":
        if (onDisplayValue[1] == "@") {
          onDisplayValue = onDisplayValue.slice(2);
          copyKey = undefined;
          storedKey[index] = copyKey;
          Settings.setLayerSettingForKey(item, prefernceKey.KEY, storedKey);
          Settings.setLayerSettingForKey(item, prefernceKey.JSON_PATH, undefined);
        } else copyKey = storedKey[index];

        break;

      default:
        copyKey = storedKey[index];
        Settings.setLayerSettingForKey(item, prefernceKey.JSON_PATH, JSONPath);
    }

    if (copyKey) {
      if (copyKey.indexOf("|") !== -1) {
        var fullValue = resolveValue(copyKey.substr(0, copyKey.indexOf("|")), copyData);
        var option = copyKey.substr(copyKey.indexOf("|") + 1).replace("…", "...").replace("⋯", "..."); // const isTruncatedByLine = option.indexOf("l") !== -1

        var charCount = fullValue.length;

        switch (option.indexOf("...")) {
          case -1:
            charCount = parseInt(option);
            JSONValue = fullValue.substr(0, charCount);
            break;

          case 0:
            charCount = parseInt(option.substr(3));
            JSONValue = fullValue.length > charCount ? fullValue.substr(0, Math.round(charCount / 2)) + "..." + fullValue.substr(-Math.round(charCount / 2)) : fullValue;
            break;

          default:
            charCount = parseInt(option.substr(0, option.indexOf("...")));
            JSONValue = fullValue.length > charCount ? fullValue.substr(0, charCount) + "..." : fullValue;
        }
      } else JSONValue = resolveValue(copyKey, copyData);
    }

    var syncCopyFromJSON = function syncCopyFromJSON() {
      if (JSONValue && JSONValue != onDisplayValue) {
        updateCounter++;
        updateText(copyItem, JSONValue);
      } else updateText(copyItem, onDisplayValue);
    };

    var syncCopyToJSON = function syncCopyToJSON() {
      if (JSONValue != onDisplayValue) {
        updateCounter++;

        if (!copyKey) {
          copyKey = camelize(item.name);

          if (itemType == layerType.SYMBOLINSTANCE) {
            copyKey = "".concat(copyKey, ".").concat(getFullName(item, copyItem));
          }

          copyKey = copyKey[0] != "@" ? copyKey : copyKey.slice(1);
          copyKey = resolveValue(copyKey, copyData) ? "".concat(copyKey, "-id:").concat(copyItem.id) : copyKey;
          storedKey[index] = copyKey;
          Settings.setLayerSettingForKey(item, prefernceKey.KEY, storedKey);
          Settings.setLayerSettingForKey(item, prefernceKey.JSON_PATH, JSONPath);
        }

        setValue(copyKey, copyData, onDisplayValue);
      }
    };

    switch (type) {
      case updateType.KEY:
        updateText(copyItem, copyKey ? "@" + copyKey : onDisplayValue);
        break;

      case updateType.FROM_JSON:
        syncCopyFromJSON();
        break;

      case updateType.TO_JSON:
        syncCopyToJSON();
        break;

      case updateType.MIXED:
        if (direction == updateDirection.FROM_JSON) syncCopyFromJSON();else syncCopyToJSON();
        break;
    }
  };

  var updateChildrenLayers = function updateChildrenLayers(layer) {
    if (layer.layers == undefined) {
      var directions = Settings.layerSettingForKey(layer, prefernceKey.UPDATE_DIRECTION);
      if (!directions) directions = [];

      switch (layer.type) {
        case layerType.TEXT:
          var direction = directions[0] ? directions[0] : updateDirection.FROM_JSON;
          updateCopyBasedOnDirection(layer, 0, direction, layerType.TEXT);
          break;

        case layerType.SYMBOLINSTANCE:
          layer.overrides.forEach(function (override, index) {
            if (override.property == "stringValue" && (Settings.settingForKey(prefernceKey.HAS_EDITABLE_ONLY_SELECTED) ? override.editable : true)) {
              var _direction = directions[index] ? directions[index] : updateDirection.FROM_JSON;

              updateCopyBasedOnDirection(layer, index, _direction, layerType.SYMBOLINSTANCE);
            }
          });

          if (type != updateType.KEY) {
            layer.resizeWithSmartLayout();
          }

          break;
      }

      return;
    } else {
      layer.layers.forEach(function (sublayer) {
        updateChildrenLayers(sublayer);
      });
    }
  };

  selectedLayers.forEach(function (layer) {
    updateChildrenLayers(layer);
  });

  switch (type) {
    case updateType.KEY:
      sketch.UI.message("📍 Reset without auto-resizing");
      break;

    case updateType.FROM_JSON:
      sketch.UI.message("\uD83D\uDE4C ".concat(updateCounter, " text(s) updated"));
      break;

    case updateType.TO_JSON:
      fs.writeFileSync(Settings.documentSettingForKey(doc, prefernceKey.KEY), JSON.stringify(copyData));
      sketch.UI.message("\uD83D\uDE4C ".concat(updateCounter, " text(s) exported. Please review other text(s) linked with the same key(s)"));
      checkUpdate(updateCounter);
      break;

    case updateType.MIXED:
      fs.writeFileSync(Settings.documentSettingForKey(doc, prefernceKey.KEY), JSON.stringify(copyData));
      sketch.UI.message("\uD83D\uDE4C ".concat(updateCounter, " text(s) synced. Please review other text(s) linked with the same key(s)"));
      checkUpdate(updateCounter);
      break;
  }

  if (Settings.settingForKey(prefernceKey.HAS_DOCUMENTATION) && type != updateType.KEY) syncCopyDoc(copyData);
};

var selectOneLayer = function selectOneLayer(layer) {
  doc.selectedLayers.clear();
  layer.selected = true;
};

var getUnsyncedPostion = function getUnsyncedPostion(string1, string2) {
  var i = 0;

  while (i < string1.length && i < string2.length && string1[i] == string2[i]) {
    i++;
  }

  return i;
};

var createButton = function createButton(label, frame) {
  var button = NSButton.alloc().initWithFrame(frame);
  button.setTitle(label);
  button.setBezelStyle(NSRoundedBezelStyle);
  button.setAction("callAction:");
  return button;
};

var createToggle = function createToggle(frame) {
  var toggle = NSButton.alloc().initWithFrame(frame);
  toggle.setButtonType(NSSwitchButton);
  toggle.setBezelStyle(0);
  toggle.setTitle("");
  toggle.setState(true);
  return toggle;
};

var createView = function createView(frame) {
  var view = NSView.alloc().initWithFrame(frame);
  view.setFlipped(true);
  return view;
};

var createDivider = function createDivider(frame) {
  var divider = NSView.alloc().initWithFrame(frame);
  divider.setWantsLayer(1);
  divider.layer().setBackgroundColor(CGColorCreateGenericRGB(0.8, 0.8, 0.8, 1.0));
  return divider;
};

var createTextLabel = function createTextLabel(text, frame) {
  var label = NSTextField.alloc().initWithFrame(frame);
  label.setStringValue(text);
  label.setFont(NSFont.systemFontOfSize(9));
  label.setTextColor(NSColor.colorWithCalibratedRed_green_blue_alpha(0, 0, 0, 0.4));
  label.setBackgroundColor(NSColor.colorWithCalibratedRed_green_blue_alpha(0, 0, 0, 0));
  label.setBezeled(false);
  label.setEditable(false);
  label.setSelectable(false);
  label.setLineBreakMode(NSLineBreakByTruncatingTail);
  return label;
};

var createCopyContent = function createCopyContent(text, frame, lineBreakMode) {
  var copy = NSTextField.alloc().initWithFrame(frame);
  copy.setStringValue(text);
  copy.setFont(NSFont.systemFontOfSize(12));
  copy.setTextColor(NSColor.colorWithCalibratedRed_green_blue_alpha(0, 0, 0, 0.7));
  copy.setBezeled(false);
  copy.setEditable(false);
  copy.setSelectable(false);
  copy.setLineBreakMode(lineBreakMode);
  return copy;
};

var createArrowBTN = function createArrowBTN(layer, index, frame) {
  var icon = NSButton.alloc().initWithFrame(frame);
  var direction = Settings.layerSettingForKey(layer, prefernceKey.UPDATE_DIRECTION);
  if (!direction) direction = [];
  direction[index] = updateDirection.FROM_JSON;
  Settings.setLayerSettingForKey(layer, prefernceKey.UPDATE_DIRECTION, direction);
  icon.addCursorRect_cursor(icon.frame(), NSCursor.pointingHandCursor());
  icon.setTitle("←");
  icon.setFont(NSFont.systemFontOfSize(16));
  icon.setBezelStyle(NSRegularSquareBezelStyle);
  icon.setAction("callAction:");
  icon.setCOSJSTargetFunction(function (sender) {
    sender.setWantsLayer(true);
    direction = Settings.layerSettingForKey(layer, prefernceKey.UPDATE_DIRECTION);

    if (icon.state()) {
      direction[index] = updateDirection.TO_JSON;
      Settings.setDocumentSettingForKey(doc, prefernceKey.UPDATE_DIRECTION, updateType.MIXED);
      icon.setTitle("→");
    } else {
      direction[index] = updateDirection.FROM_JSON;
      icon.setTitle("←");
    }

    Settings.setLayerSettingForKey(layer, prefernceKey.UPDATE_DIRECTION, direction);
  });
  return icon;
};

var createScrollView = function createScrollView(frame) {
  var panel = NSScrollView.alloc().initWithFrame(frame);
  panel.setHasVerticalScroller(true);
  panel.addSubview(createDivider(NSMakeRect(0, 0, frame.size.width, 1)));
  panel.addSubview(createDivider(NSMakeRect(0, frame.size.height - 1, frame.size.width, 1)));
  return panel;
};

var createPopupDialog = function createPopupDialog(title, frame) {
  var panel = NSPanel.alloc().init();
  panel.setTitle(title);
  panel.setFrame_display(frame, true);
  panel.setStyleMask(NSTexturedBackgroundWindowMask | NSTitledWindowMask | NSClosableWindowMask | NSFullSizeContentViewWindowMask);
  panel.setBackgroundColor(NSColor.colorWithCalibratedRed_green_blue_alpha(0.9, 0.9, 0.9, 1));
  panel.setLevel(NSFloatingWindowLevel);
  panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true);
  panel.standardWindowButton(NSWindowZoomButton).setHidden(true);
  panel.makeKeyAndOrderFront(null);
  panel.center();
  return panel;
};

var createClickableArea = function createClickableArea(layer, override, frame) {
  var hotspot = NSButton.alloc().initWithFrame(frame);
  hotspot.addCursorRect_cursor(hotspot.frame(), NSCursor.pointingHandCursor());
  hotspot.setTransparent(true);
  hotspot.setAction("callAction:");
  hotspot.setCOSJSTargetFunction(function (sender) {
    sender.setWantsLayer(true);

    if (override) {
      selectOneLayer(override);
    } else selectOneLayer(layer);

    layer.getParentPage().selected = true;
    doc.centerOnLayer(layer);
  });
  return hotspot;
};

var displayUnsyncedCopy = function displayUnsyncedCopy(layerIndex, copyIndex, unsyncedLayers) {
  var item = unsyncedLayers[layerIndex];
  var copy = item.list[copyIndex];
  var unsyncedPosition = getUnsyncedPostion(copy.sketchCopy, copy.dataCopy);
  var startPosition = unsyncedPosition < 60 ? 0 : unsyncedPosition - 60;
  var contentList = [];
  var displayedSketchCopy = [copy.sketchCopy.slice(0, unsyncedPosition), "🔺", copy.sketchCopy.slice(unsyncedPosition)].join("").substr(startPosition);
  displayedSketchCopy = startPosition == 0 ? displayedSketchCopy : "..." + displayedSketchCopy;
  var displayedDataCopy = [copy.dataCopy.slice(0, unsyncedPosition), "🔺", copy.dataCopy.slice(unsyncedPosition)].join("").substr(startPosition);
  displayedDataCopy = startPosition == 0 ? displayedDataCopy : "..." + displayedDataCopy;
  var copySetFrame = createView(NSMakeRect(panelMargin * 2, (itemHeight + panelMargin) * copyIndex + panelMargin / 2, panelWidth - panelMargin * 2, itemHeight + panelMargin));
  var copySetConetent = createView(NSMakeRect(0, panelMargin / 2, panelWidth - panelMargin * 2, itemHeight));
  var clickableArea = createClickableArea(item.layer, item.type == layerType.SYMBOLINSTANCE ? copy.override : false, NSMakeRect(0, 0, panelWidth - panelMargin * 2, itemHeight + panelMargin));
  var syncDirectionIcon = createArrowBTN(item.layer, copy.index, NSMakeRect(itemWidth * 2 + panelMargin * 0.5, panelMargin * 0.5, panelMargin * 2, panelMargin * 2));
  contentList = [copySetConetent, clickableArea, syncDirectionIcon];
  contentList.forEach(function (item) {
    return copySetFrame.addSubview(item);
  });
  var copyLayerName = createCopyContent(item.name, NSMakeRect(panelMargin, 0, itemWidth - panelMargin * 2, itemHeight), NSLineBreakByTruncatingTail, NSColor.colorWithCalibratedRed_green_blue_alpha(0, 0, 0, 0.7), 0.1);
  var copyLabel = createTextLabel("@" + copy.label, NSMakeRect(panelMargin, panelMargin, itemWidth - panelMargin * 2, itemHeight), NSLineBreakByTruncatingTail);
  var sketchCopyContent = createCopyContent(displayedSketchCopy, NSMakeRect(itemWidth, 0, itemWidth, itemHeight), NSLineBreakByWordWrapping);
  var dataCopyContent = createCopyContent(displayedDataCopy, NSMakeRect(itemWidth * 2 + panelMargin * 3, 0, itemWidth, itemHeight), NSLineBreakByWordWrapping);
  contentList = [copyLayerName, copyLabel, sketchCopyContent, dataCopyContent];
  contentList.forEach(function (item) {
    return copySetConetent.addSubview(item);
  });
  return {
    block: copySetFrame,
    direction: syncDirectionIcon
  };
};

var displayResult = function displayResult(unsyncedLayers, unsyncedCopyAmount) {
  var totalHeight = unsyncedCopyAmount * (itemHeight + panelMargin) + unsyncedLayers.length * panelMargin + panelMargin * 4;
  var panelHeight = totalHeight < maxPanelHeight ? totalHeight : maxPanelHeight;
  var prevCopyAmount = 0;
  var dialog = createPopupDialog("Review Unsynced Copy", NSMakeRect(0, 0, panelWidth + scrollBarWidth, panelHeight + 44));
  var fiber = sketch.Async.createFiber();
  var dialogClose = dialog.standardWindowButton(NSWindowCloseButton);
  dialogClose.setCOSJSTargetFunction(function () {
    dialog.close();
    fiber.cleanup();
  });
  Settings.setDocumentSettingForKey(doc, prefernceKey.UPDATE_DIRECTION, updateType.FROM_JSON);
  var dialogContent = createView(NSMakeRect(0, 0, panelWidth + scrollBarWidth, panelHeight));
  var layerLabel = createTextLabel("Unsynced layer", NSMakeRect(panelMargin, panelMargin, itemWidth, panelMargin));
  var sketchCopyLable = createTextLabel("Text in Sketch", NSMakeRect(itemWidth + panelMargin * 2, panelMargin, itemWidth, panelMargin));
  var dataCopyLabel = createTextLabel("Text in JSON", NSMakeRect(itemWidth * 2 + panelMargin * 5, panelMargin, itemWidth, panelMargin));
  var resultListScrollView = createScrollView(NSMakeRect(0, panelMargin * 2, panelWidth + scrollBarWidth, panelHeight - panelMargin * 4));
  var resultListScrollContent = createView(NSMakeRect(0, 0, panelWidth, totalHeight - panelMargin * 4));
  unsyncedLayers.forEach(function (item, i) {
    var layerFrame = createView(NSMakeRect(0, panelMargin * i + (panelMargin + itemHeight) * prevCopyAmount, panelWidth, panelMargin + (itemHeight + panelMargin) * item.list.length));
    var topDivider = createDivider(NSMakeRect(0, 0, panelWidth, 1));
    var syncToggle = createToggle(NSMakeRect(panelMargin, panelMargin, 36, 36));
    var unSyncedCopySets = [topDivider, syncToggle];
    var syncDirectionSets = [];
    item.list.forEach(function (copy, j) {
      var copySet = displayUnsyncedCopy(i, j, unsyncedLayers);
      unSyncedCopySets.push(copySet.block);
      syncDirectionSets.push(copySet.direction);
    });
    syncToggle.setCOSJSTargetFunction(function (sender) {
      item.selected = sender.state();
      syncDirectionSets.forEach(function (direction) {
        return direction.setEnabled(sender.state());
      });
    });
    unSyncedCopySets.forEach(function (copySet) {
      return layerFrame.addSubview(copySet);
    });
    resultListScrollContent.addSubview(layerFrame);
    prevCopyAmount += item.list.length;
  });
  resultListScrollView.setDocumentView(resultListScrollContent);
  var cancelButton = createButton("Cancel", NSMakeRect(panelWidth - 220, panelHeight - panelMargin * 1.9, 80, 36));
  var updateButton = createButton("Update Selected", NSMakeRect(panelWidth - 140, panelHeight - panelMargin * 1.9, 140, 36));
  var dialogContentList = [layerLabel, sketchCopyLable, dataCopyLabel, resultListScrollView, cancelButton, updateButton];
  dialogContentList.forEach(function (item) {
    return dialogContent.addSubview(item);
  });
  dialog.contentView().addSubview(dialogContent);
  cancelButton.setCOSJSTargetFunction(function () {
    dialog.close();
    fiber.cleanup();
  });
  updateButton.setCOSJSTargetFunction(function () {
    doc.selectedLayers.clear();
    unsyncedLayers.forEach(function (item) {
      return item.layer.selected = item.selected;
    });
    updateTextByType(Settings.documentSettingForKey(doc, prefernceKey.UPDATE_DIRECTION));
    dialog.close();
    fiber.cleanup();
  });
};

var checkUpdateOnOpenDocument = function checkUpdateOnOpenDocument(context) {
  if (!Settings.settingForKey(prefernceKey.IS_CHECK)) return;
  setTimeout(function () {
    doc = sketch.fromNative(context.actionContext.document);
    selectedLayers = doc.selectedLayers;
    checkUpdate();
  }, 1000);
};
var checkUpdate = function checkUpdate(updateCounter) {
  var copyData = readDatafromConfig();
  if (!copyData) return;
  var unsyncedLayers = [];
  var unsyncedCopyAmount = 0;

  var createUnsyncedData = function createUnsyncedData(layer, type, list) {
    return {
      id: layer.id,
      name: layer.name,
      layer: layer,
      type: type,
      selected: true,
      list: list
    };
  };

  var checkChildrenLayers = function checkChildrenLayers(layer) {
    if (layer.layers == undefined) {
      copyData = readDatafromConfig(Settings.layerSettingForKey(layer, prefernceKey.JSON_PATH));
      if (!copyData) return;
      var storedKey = Settings.layerSettingForKey(layer, prefernceKey.KEY);
      if (!storedKey) return;

      switch (layer.type) {
        case layerType.TEXT:
          var copyKey = storedKey[0];
          var JSONValue = resolveValue(copyKey, copyData);

          if (JSONValue && layer.text != JSONValue) {
            unsyncedLayers.push(createUnsyncedData(layer, layerType.TEXT, [{
              label: copyKey,
              sketchCopy: layer.text,
              dataCopy: JSONValue,
              index: 0
            }]));
            unsyncedCopyAmount++;
          }

          break;

        case layerType.SYMBOLINSTANCE:
          var unsyncedOverride = [];
          layer.overrides.forEach(function (override, index) {
            var copyKey = storedKey[index];

            if (copyKey && override.property == "stringValue" && override.editable) {
              var _JSONValue = resolveValue(copyKey, copyData);

              if (_JSONValue && override.value != _JSONValue) {
                unsyncedOverride.push({
                  label: copyKey,
                  sketchCopy: override.value,
                  dataCopy: _JSONValue,
                  override: override,
                  index: index
                });
                unsyncedCopyAmount++;
              }
            }
          });

          if (unsyncedOverride.length != 0) {
            unsyncedLayers.push(createUnsyncedData(layer, layerType.SYMBOLINSTANCE, unsyncedOverride));
          }

          break;
      }
    } else layer.layers.forEach(function (sublayer) {
      return checkChildrenLayers(sublayer);
    });
  };

  var checkScope = Settings.settingForKey(prefernceKey.CHECK_SCOPE) ? Settings.settingForKey(prefernceKey.CHECK_SCOPE) : 0;

  switch (checkScope) {
    case 0:
      // Selected page
      doc.pages.forEach(function (page) {
        if (page.selected && page != Settings.documentSettingForKey(doc, prefernceKey.COPY_PAGE_ID)) checkChildrenLayers(page);
      });
      break;

    case 1:
      // Pages starting with "@"
      doc.pages.forEach(function (page) {
        if (page.name[0] == "@" && page != Settings.documentSettingForKey(doc, prefernceKey.COPY_PAGE_ID)) checkChildrenLayers(page);
      });
      break;

    case 2:
      // Entire document
      doc.pages.forEach(function (page) {
        if (page.id != Settings.documentSettingForKey(doc, prefernceKey.COPY_PAGE_ID)) checkChildrenLayers(page);
      });
      break;

    default:
  }

  if (unsyncedLayers.length !== 0) {
    displayResult(unsyncedLayers, unsyncedCopyAmount);
  } else {
    if (typeof updateCounter == "number") {
      sketch.UI.message("\uD83D\uDE4C ".concat(updateCounter, " text(s) exported and no unsynced texts found "));
    } else sketch.UI.message("🙌 No unsynced texts found");
  }
};
var resetCopy = function resetCopy() {
  updateTextByType(updateType.KEY);
};
var pullCopy = function pullCopy() {
  updateTextByType(updateType.FROM_JSON);
};
var pushCopy = function pushCopy() {
  var isPushingFromCopyIndex = false;
  selectedLayers.layers.forEach(function (layer) {
    isPushingFromCopyIndex = layer.getParentPage().id == Settings.documentSettingForKey(doc, prefernceKey.COPY_PAGE_ID);
  });

  if (!isPushingFromCopyIndex) {
    updateTextByType(updateType.TO_JSON);
  } else sketch.UI.message("This is a reference page. Please modify the JSON file or the text in your design and push to JSON.");
};
var generateJSON = function generateJSON() {
  var sourceFilePath = _skpm_dialog__WEBPACK_IMPORTED_MODULE_0___default.a.showSaveDialogSync(doc, {});

  if (sourceFilePath) {
    Settings.setDocumentSettingForKey(doc, prefernceKey.KEY, sourceFilePath);
    var initData = {};
    initData[sourceFilePath] = copyBlockSpec.copyPageName + ": " + getFileName(sourceFilePath);
    fs.writeFileSync(sourceFilePath, JSON.stringify(initData));
    JSONPath = sourceFilePath;
    updateTextByType(updateType.TO_JSON);
  }
};
var setupJSON = function setupJSON() {
  var selectedFile = _skpm_dialog__WEBPACK_IMPORTED_MODULE_0___default.a.showOpenDialogSync(doc, {
    properties: ["openFile"],
    filters: [{
      extensions: ["json"]
    }]
  });
  JSONPath = selectedFile[0];
  isJSONPathUpdated = true;
  if (JSONPath) Settings.setDocumentSettingForKey(doc, prefernceKey.KEY, JSONPath);
  if (!selectedLayers.isEmpty) pullCopy();
};

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['setupJSON'] = __skpm_run.bind(this, 'setupJSON');
globalThis['onRun'] = __skpm_run.bind(this, 'default');
globalThis['generateJSON'] = __skpm_run.bind(this, 'generateJSON');
globalThis['pullCopy'] = __skpm_run.bind(this, 'pullCopy');
globalThis['pushCopy'] = __skpm_run.bind(this, 'pushCopy');
globalThis['resetCopy'] = __skpm_run.bind(this, 'resetCopy');
globalThis['checkUpdate'] = __skpm_run.bind(this, 'checkUpdate');
globalThis['checkUpdateOnOpenDocument'] = __skpm_run.bind(this, 'checkUpdateOnOpenDocument')

//# sourceMappingURL=__script.js.map