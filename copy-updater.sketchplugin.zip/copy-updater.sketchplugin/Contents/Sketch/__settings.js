var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/settings.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/settings.js":
/*!*************************!*\
  !*** ./src/settings.js ***!
  \*************************/
/*! exports provided: createSettingPanel, updateSettings, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createSettingPanel", function() { return createSettingPanel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateSettings", function() { return updateSettings; });
var sketch = __webpack_require__(/*! sketch */ "sketch");

var Settings = sketch.Settings;
var UI = sketch.UI;
var responseOptions = {
  SAVE: 1000,
  CANCEL: 1002
};
var prefernceKey = {
  IS_CHECK: "isCheckOnOpenDocument",
  HAS_DOCUMENTATION: "hasCopyDocumentation",
  CHECK_SCOPE: "copyCheckScope",
  HAS_EDITABLE_ONLY_SELECTED: "hasExportEditableOnlySelected",
  EXPORT_ORIENTATION: "exportOrientation",
  EXPORT_SLICE_ONLY: "exportSliceOnly",
  EXPORT_AT_COPY_ONLY: "exportAtCopyOnly",
  EXPORT_INVIEW_ONLY: "exportInViewOnly",
  HAS_COPY_REVISION: "hasCopyRevision",
  HAS_COPY_INDEX: "hasCopyIndex",
  HAS_COPY_KEY: "hasCopyKey"
};
var panelSpec = {
  width: 300,
  height: 375,
  lineHeight: 25
};
var checkScopeOptions = ["Selected page", 'Pages starting with "@"', "Entire document"];
var exportOrientationOptions = ["Layout orientation: Horizontal", "Layout orientation: Vertical"];

var UIComponentRect = function UIComponentRect(y) {
  return NSMakeRect(0, panelSpec.height - y, panelSpec.width, panelSpec.lineHeight);
};

var checkCopyToggle, copyDocumentationToggle, exportAllStringsToggle, exportSliceOnlyToggle, exportAtCopyOnlyToggle, exportInViewOnlyToggle, copyRevisionToggle, copyIndexToggle, copyKeyToggle, checkScopeDropdown, exportOrientationDropdown;

var createLabel = function createLabel(positionY, text) {
  var label = NSTextField.alloc().initWithFrame(UIComponentRect(positionY));
  label.setStringValue(text);
  label.setSelectable(false);
  label.setEditable(false);
  label.setBezeled(false);
  label.setDrawsBackground(false);
  return label;
};

var createToggle = function createToggle(positionY, settingKey, text) {
  var toggle = NSButton.alloc().initWithFrame(UIComponentRect(positionY));
  var initValue = Settings.settingForKey(settingKey) === 1 ? NSOnState : NSOffState;
  toggle.setButtonType(NSSwitchButton);
  toggle.setBezelStyle(0);
  toggle.setTitle(text);
  toggle.setState(initValue);
  return toggle;
};

var createDropdown = function createDropdown(positionY, possibleValue, initValue) {
  var dropdowm = NSPopUpButton.alloc().initWithFrame(UIComponentRect(positionY));
  var initialIndex = possibleValue.indexOf(initValue);
  dropdowm.addItemsWithTitles(possibleValue);
  dropdowm.selectItemAtIndex(initialIndex !== -1 ? initialIndex : 0);
  return dropdowm;
};

var createSettingPanel = function createSettingPanel() {
  var panel = COSAlertWindow.new();
  panel.setIcon(__command.pluginBundle().alertIcon());
  panel.setMessageText("Copy Updater Settings");
  panel.addButtonWithTitle("Save");
  panel.addButtonWithTitle("Cancel");
  var view = NSView.alloc().initWithFrame(NSMakeRect(0, 0, panelSpec.width, panelSpec.height));
  panel.addAccessoryView(view);
  var y = 0; // -------------------------------------------------
  //  Check Scope
  // -------------------------------------------------

  y += 30;
  var checkScopeLabel = createLabel(y, "Copy check scope:");
  y += 20;
  checkScopeDropdown = createDropdown(y, checkScopeOptions, checkScopeOptions[Settings.settingForKey(prefernceKey.CHECK_SCOPE)]); // -------------------------------------------------
  //  Excel
  // -------------------------------------------------

  y += 50;
  var exportOrientationLabel = createLabel(y, "Excel settings:");
  y += 20;
  exportOrientationDropdown = createDropdown(y, exportOrientationOptions, exportOrientationOptions[Settings.settingForKey(prefernceKey.EXPORT_ORIENTATION)]);
  y += 25;
  exportSliceOnlyToggle = createToggle(y, prefernceKey.EXPORT_SLICE_ONLY, "Only export slices with 'copy' as Prefix or Suffix");
  y += 20;
  exportAtCopyOnlyToggle = createToggle(y, prefernceKey.EXPORT_AT_COPY_ONLY, "Only export layers with '@@' as name prefix");
  y += 20;
  exportInViewOnlyToggle = createToggle(y, prefernceKey.EXPORT_INVIEW_ONLY, "Ignore content outside of artboards");
  y += 20;
  copyIndexToggle = createToggle(y, prefernceKey.HAS_COPY_INDEX, "Add markers on the screen and an index column");
  y += 20;
  copyKeyToggle = createToggle(y, prefernceKey.HAS_COPY_KEY, "Add a copy name column");
  y += 20;
  copyRevisionToggle = createToggle(y, prefernceKey.HAS_COPY_REVISION, "Add a copy revision column"); // -------------------------------------------------
  //  Other
  // -------------------------------------------------

  y += 50;
  var otherLabel = createLabel(y, "Other settings:");
  y += 20;
  checkCopyToggle = createToggle(y, prefernceKey.IS_CHECK, "Check copy when open a Sketch document");
  y += 20;
  exportAllStringsToggle = createToggle(y, prefernceKey.HAS_EDITABLE_ONLY_SELECTED, "Only export editable text to JSON");
  y += 20;
  copyDocumentationToggle = createToggle(y, prefernceKey.HAS_DOCUMENTATION, "Maintain a copy index page");
  view.addSubview(checkScopeLabel);
  view.addSubview(checkScopeDropdown);
  view.addSubview(exportSliceOnlyToggle);
  view.addSubview(exportAtCopyOnlyToggle);
  view.addSubview(exportInViewOnlyToggle);
  view.addSubview(copyIndexToggle);
  view.addSubview(copyKeyToggle);
  view.addSubview(copyRevisionToggle);
  view.addSubview(exportOrientationLabel);
  view.addSubview(exportOrientationDropdown);
  view.addSubview(otherLabel);
  view.addSubview(checkCopyToggle);
  view.addSubview(copyDocumentationToggle);
  view.addSubview(exportAllStringsToggle);
  return panel.runModal();
};
var updateSettings = function updateSettings() {
  var checkScope = checkScopeDropdown.indexOfSelectedItem();
  var orientation = exportOrientationDropdown.indexOfSelectedItem();
  Settings.setSettingForKey(prefernceKey.CHECK_SCOPE, checkScope);
  Settings.setSettingForKey(prefernceKey.EXPORT_SLICE_ONLY, exportSliceOnlyToggle.state());
  Settings.setSettingForKey(prefernceKey.EXPORT_AT_COPY_ONLY, exportAtCopyOnlyToggle.state());
  Settings.setSettingForKey(prefernceKey.EXPORT_INVIEW_ONLY, exportInViewOnlyToggle.state());
  Settings.setSettingForKey(prefernceKey.HAS_COPY_INDEX, copyIndexToggle.state());
  Settings.setSettingForKey(prefernceKey.HAS_COPY_KEY, copyKeyToggle.state());
  Settings.setSettingForKey(prefernceKey.HAS_COPY_REVISION, copyRevisionToggle.state());
  Settings.setSettingForKey(prefernceKey.EXPORT_ORIENTATION, orientation);
  Settings.setSettingForKey(prefernceKey.IS_CHECK, checkCopyToggle.state());
  Settings.setSettingForKey(prefernceKey.HAS_EDITABLE_ONLY_SELECTED, exportAllStringsToggle.state());
  Settings.setSettingForKey(prefernceKey.HAS_DOCUMENTATION, copyDocumentationToggle.state());
  UI.message("\u2705 Successfully updated");
};
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var response = createSettingPanel();

  switch (response) {
    case responseOptions.SAVE:
      updateSettings();
      break;

    case responseOptions.CANCEL:
      break;
  }
});

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__settings.js.map